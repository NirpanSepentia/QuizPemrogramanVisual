﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        golongan.Items.Add("IIIA")
        golongan.Items.Add("IIIB")
        golongan.Items.Add("IIIC")

        ComboBox1.Items.Add("Menikah")
        ComboBox1.Items.Add("Belum Menikah")

        nip.Items.Add("A0001")
        nip.Items.Add("A0002")
        nip.Items.Add("A0003")
        nip.Items.Add("A0004")

    End Sub

    Private Sub golongan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles golongan.SelectedIndexChanged
        If golongan.Text = "IIIA" Then
            TextBox1.Text = 4500000
        ElseIf golongan.Text = "IIIB" Then
            TextBox2.Text = 4000000
        ElseIf golongan.Text = "IIIC" Then
            TextBox3.Text = 3500000
        Else
            TextBox1.Text = 0
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox3.Text = Val(TextBox2.Text) + Val(TextBox1.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Menikah" Then
            TextBox2.Text = 0.25 * TextBox1.Text
        ElseIf ComboBox1.Text = "Belum Menikah" Then
            TextBox2.Text = 0.15 * TextBox1.Text
        Else
            TextBox2.Text = 0
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        nip.Text = ""
        nama.Text = ""
        golongan.Text = ""
        TextBox1.Text = ""
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub nip_SelectedIndexChanged(sender As Object, e As EventArgs) Handles nip.SelectedIndexChanged
        If nip.Text = "A0001" Then
            nama.Text = "Nirpan Sepentia"
        ElseIf nip.Text = "A0002" Then
            nama.Text = "Rijal Juniansyah"
        ElseIf nip.Text = "A0003" Then
            nama.Text = "Nisa Muharani"
        ElseIf nip.Text = "A0004" Then
            nama.Text = "Christiano Ronaldo"
        Else
            nama.Text = 0

        End If
    End Sub
End Class
